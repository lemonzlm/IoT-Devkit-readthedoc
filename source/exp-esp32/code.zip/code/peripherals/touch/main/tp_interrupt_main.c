/*
 * SPDX-FileCopyrightText: 2021 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_log.h"

#include "driver/touch_pad.h"
#include "soc/rtc_periph.h"
#include "soc/sens_periph.h"

static const char *TAG = "Touch pad";

#define TOUCH_THRESH_NO_USE   (0)
#define TOUCH_THRESH_PERCENT  (80)
#define TOUCHPAD_FILTER_TOUCH_PERIOD (10)

static bool s_pad_activated[TOUCH_PAD_MAX];
static uint32_t s_pad_init_val[TOUCH_PAD_MAX];

/*
  Read values sensed at all available touch pads.
  Use 2 / 3 of read value as the threshold
  to trigger interrupt when the pad is touched.
  Note: this routine demonstrates a simple way
  to configure activation threshold for the touch pads.
  Do not touch any pads when this routine
  is running (on application start).
  在所有可用的触摸传感器上感应到的读取值。
  使用读取值的2/3作为阈值
  当触摸垫被触摸时触发中断。
  注意：这个程序展示了一个简单的方法
  为触摸传感器配置激活阈值的简单方法。
  当此例程运行时，请不要触摸任何引脚
  运行时（在应用程序启动时），不要触摸任何引脚。
 */
static void tp_example_set_thresholds(void)
{
    uint16_t touch_value;
    for (int i = 0; i < TOUCH_PAD_MAX; i++) {
        //read filtered value 读取滤波后的电压值
        touch_pad_read_filtered(i, &touch_value);
        s_pad_init_val[i] = touch_value;
        ESP_LOGI(TAG, "test init: touch pad [%d] val is %d", i, touch_value);
        //set interrupt threshold. 设置触发中断的阈值
        ESP_ERROR_CHECK(touch_pad_set_thresh(i, touch_value * 3 / 3));

    }
}

/*
  Check if any of touch pads has been activated
  by reading a table updated by rtc_intr()
  If so, then print it out on a serial monitor.
  Clear related entry in the table afterwards

  In interrupt mode, the table is updated in touch ISR.

  In filter mode, we will compare the current filtered value with the initial one.
  If the current filtered value is less than 80% of the initial value, we can
  regard it as a 'touched' event.
  When calling touch_pad_init, a timer will be started to run the filter.
  This mode is designed for the situation that the pad is covered
  by a 2-or-3-mm-thick medium, usually glass or plastic.
  The difference caused by a 'touch' action could be very small, but we can still use
  filter mode to detect a 'touch' event.
  检查是否有触摸传感器被激活
  读取由rtc_intr()函数更新的表格。
  如果是的话，就把它打印在一个串行显示器上。
  之后清除表中的相关条目
  在中断模式下，该表在触摸ISR中被更新。
  在过滤模式下，我们将比较当前过滤的值和初始值。
  如果当前的过滤值小于初始值的80%，我们可以
  将其视为一个 "被触摸"事件。
  当调用touch_pad_init时，将启动一个定时器来运行过滤器。
  这种模式是为传感器被2-3毫米厚的介质覆盖的情况而设计的，通常是玻璃或塑料。
  由 "触摸"动作引起的变化可能非常小，但我们仍然可以使用滤波器模式来检测一个 "触摸"事件。
 */
static void tp_example_read_task(void *pvParameter)
{
    static int show_message;
    int change_mode = 0;
    int filter_mode = 0;
    while (1) {
        if (filter_mode == 0) {
            //interrupt mode, enable touch interrupt 中断模式，使能触摸中断
            touch_pad_intr_enable();
            for (int i = 0; i < TOUCH_PAD_MAX; i++) {
                if (s_pad_activated[i] == true) {
                    ESP_LOGI(TAG, "T%d activated!", i);
                    // Wait a while for the pad being released 等传感器电容放电
                    vTaskDelay(200 / portTICK_PERIOD_MS);
                    // Clear information on pad activation 清除触摸传感器的激活标志
                    s_pad_activated[i] = false;
                    // Reset the counter triggering a message
                    // that application is running
                    //重置计数器触发应用程序正在运行的消息
                    show_message = 1;
                }
            }
        } else {
            //filter mode, disable touch interrupt 过滤模式，禁用触摸中断
            touch_pad_intr_disable();
            touch_pad_clear_status();
            for (int i = 0; i < TOUCH_PAD_MAX; i++) {
                uint16_t value = 0;
                touch_pad_read_filtered(i, &value);
                if (value < s_pad_init_val[i] * TOUCH_THRESH_PERCENT / 100) {
                    ESP_LOGI(TAG, "T%d activated!", i);
                    ESP_LOGI(TAG, "value: %d; init val: %d", value, s_pad_init_val[i]);
                    vTaskDelay(200 / portTICK_PERIOD_MS);
                    // Reset the counter to stop changing mode.重置计数器以停止更改模式
                    change_mode = 1;
                    show_message = 1;
                }
            }
        }

        vTaskDelay(10 / portTICK_PERIOD_MS);

        // If no pad is touched, every couple of seconds, show a message
        // that application is running
        //如果没有接触到传感器，每隔几秒钟就会显示一条应用程序正在运行的信息
        if (show_message++ % 500 == 0) {
            ESP_LOGI(TAG, "Waiting for any pad being touched...");
        }
        // Change mode if no pad is touched for a long time.如果长时间没有触摸引脚，则更改模式
        // We can compare the two different mode.我们可以比较两种不同的模式
        if (change_mode++ % 2000 == 0) {
            filter_mode = !filter_mode;
            ESP_LOGW(TAG, "Change mode...%s", filter_mode == 0 ? "interrupt mode" : "filter mode");
        }
    }
}

/*
  Handle an interrupt triggered when a pad is touched.
  Recognize what pad has been touched and save it in a table.
  处理触摸板时触发的中断。
  识别触摸过的传感器并将其保存在表格中。
 */
static void tp_example_rtc_intr(void *arg)
{
    uint32_t pad_intr = touch_pad_get_status();
    //清除中断标志
    touch_pad_clear_status();
    for (int i = 0; i < TOUCH_PAD_MAX; i++) {
        if ((pad_intr >> i) & 0x01) {
            s_pad_activated[i] = true;
        }
    }
}

/*
 * Before reading touch pad, we need to initialize the RTC IO.
 * 在读取触摸传感器之前，我们需要初始化 RTC IO
 */
static void tp_example_touch_pad_init(void)
{
    for (int i = 0; i < TOUCH_PAD_MAX; i++) {
    //初始化RTC IO和触摸传感器模式
        touch_pad_config(i, TOUCH_THRESH_NO_USE);
    }
}

void app_main(void)
{
    // 初始化触摸传感器外设，它会启动一个定时器来作为一个滤波器
    ESP_LOGI(TAG, "Initializing touch pad");
    ESP_ERROR_CHECK(touch_pad_init());
    // If use interrupt trigger mode, should set touch sensor FSM mode at 'TOUCH_FSM_MODE_TIMER'.
    // 如果使用中断触发模式，应将触摸传感器 FSM 模式设置为“TOUCH_FSM_MODE_TIMER”。
    touch_pad_set_fsm_mode(TOUCH_FSM_MODE_TIMER);
    // Set reference voltage for charging/discharging
    // For most usage scenarios, we recommend using the following combination:
    // the high reference valtage will be 2.7V - 1V = 1.7V, The low reference voltage will be 0.5V.
    // 设置充电/放电的参考电压
    // 对于大多数使用情况，我们建议使用以下组合。
    // 高参考电压将是2.7V - 1V = 1.7V，低参考电压将是0.5V。
    touch_pad_set_voltage(TOUCH_HVOLT_2V7, TOUCH_LVOLT_0V5, TOUCH_HVOLT_ATTEN_1V);
    // 初始化触摸传感器IO
    tp_example_touch_pad_init();
    // 初始化并启动软件滤波器以检测电容的微小变化。
    touch_pad_filter_start(TOUCHPAD_FILTER_TOUCH_PERIOD);
    // 设置保持触发阈值
    tp_example_set_thresholds();
    // 注册触摸中断 ISR
    touch_pad_isr_register(tp_example_rtc_intr, NULL);
    // 启动监视器任务以显示触摸了哪些引脚
    xTaskCreate(&tp_example_read_task, "touch_pad_read_task", 2048, NULL, 5, NULL);
}
